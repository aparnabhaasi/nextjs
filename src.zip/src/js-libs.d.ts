declare module 'gumshoejs'
declare module 'google-maps-react'
